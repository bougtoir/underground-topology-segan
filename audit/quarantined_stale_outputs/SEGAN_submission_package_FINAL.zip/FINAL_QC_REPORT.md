# Final QC report

- Generated: 2026-09-24T15:36:42.515727+00:00
- Canonical originals unchanged: True
- Required artifacts present: True
- Frozen headline values found in manuscript: True
- Prohibited legacy claim hits: []
- All headline primary networks feasible: True
- Uncertainty draws per municipality: 5000
- Machine verdict: pass

The clean-room and hostile-review gates are recorded separately and must pass
before the package is declared submission-ready.
