"""Build the corrected SEGAN manuscript from frozen machine-readable values."""
import csv
import os

import pandas as pd
import yaml
from docx import Document
from docx.oxml import parse_xml
from docx.shared import Pt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
values = {r["key"]: r["value"] for r in csv.DictReader(
    open(f"{ROOT}/FINAL_MANUSCRIPT_VALUES.csv", encoding="utf-8"))}
refs = list(csv.DictReader(open(
    f"{ROOT}/analysis/references_verified.csv", encoding="utf-8")))
spec = yaml.safe_load(open(
    f"{ROOT}/ENGINEERING_FEASIBILITY_SPEC.yaml", encoding="utf-8"))
config = yaml.safe_load(open(f"{ROOT}/config/study.yaml", encoding="utf-8"))
scenario = pd.read_csv(f"{ROOT}/analysis/scenario_results.csv").set_index("city")
sensitivity = pd.read_csv(
    f"{ROOT}/analysis/sensitivity_mc.csv").set_index("city")
decomposition = pd.read_csv(
    f"{ROOT}/analysis/ablation_decomposition.csv").set_index("city")
audit = pd.read_csv(f"{ROOT}/MUNICIPAL_DATA_PROVENANCE_AUDIT.csv").set_index(
    "municipality")
sensitivity_config = config["sensitivity"]
sensitivity_ranges = sensitivity_config["ranges"]


def v(key):
    return float(values[key])


def f(key, digits=2):
    return f"{v(key):.{digits}f}"


def bn(number):
    return f"{float(number) / 1e9:.2f}"


doc = Document()
normal = doc.styles["Normal"]
normal.font.name = "Times New Roman"
normal.font.size = Pt(11)


def equation(text):
    p = doc.add_paragraph()
    xml = (
        '<m:oMathPara xmlns:m="http://schemas.openxmlformats.org/'
        'officeDocument/2006/math"><m:oMath><m:r><m:t>'
        f"{text}</m:t></m:r></m:oMath></m:oMathPara>")
    p._p.append(parse_xml(xml))


ref_by_doi = {r["doi"]: r for r in refs}
cite_order = []


def cite(paragraph, doi):
    if doi not in cite_order:
        cite_order.append(doi)
    run = paragraph.add_run(str(cite_order.index(doi) + 1))
    run.font.superscript = True


D = {
    "baran_rec": "10.1109/61.25627",
    "baran_cap": "10.1109/61.19265",
    "pandapower": "10.1109/TPWRS.2018.2829021",
    "hwang": "10.1002/net.3230220105",
    "kou": "10.1007/BF00288961",
    "osm": "10.1109/MPRV.2008.80",
    "condsel": "10.1109/59.43199",
    "under": "10.1016/j.epsr.2022.108804",
    "linopf": "10.1109/PSCC.2014.7038399",
    "ga_dnp": "10.1109/PESMG.2013.6672615",
    "ross": "10.1002/9781119125204",
}

doc.add_heading(
    "Engineering-feasible life-cycle optimization for underground "
    "distribution renewal: separating topology and conductor-sizing value "
    "under reconstruction uncertainty", 0)
doc.add_paragraph(
    "Original research article prepared for Sustainable Energy, Grids and "
    "Networks")
doc.add_paragraph("[Authors and affiliations to be completed locally]")
doc.add_paragraph("Corresponding author: [to be completed locally]")

doc.add_heading("Abstract", 1)
total_clusters = int(scenario.clusters.sum())
abstract = (
    "Underground distribution renewal can preserve a reconstructed legacy "
    "route or use the construction window to reconsider routing and equipment. "
    "We estimate the life-cycle value of this decision while enforcing an "
    "explicit 6.6-kV primary, transformer, 210-V secondary and 105-V customer "
    "service hierarchy. Legacy networks are reconstructed as ensembles on "
    "road graphs; feasible candidates must satisfy connectivity, radiality, "
    "power balance, voltage and thermal gates. A weighted Steiner heuristic "
    "and catalog-based conductor and transformer choices are evaluated for "
    f"{total_clusters} clusters in three Japanese municipal study zones. "
    "Relative to like-for-like undergrounding, the corrected optimized "
    f"scenario reduces modeled 40-year net present cost by "
    f"{f('sano_ltp_pct', 1)}%, {f('kudamatsu_ltp_pct', 1)}% and "
    f"{f('yasu_ltp_pct', 1)}% in Sano, Kudamatsu and Yasu, respectively. "
    "Ablation attributes most savings to conductor sizing rather than route "
    "topology. Unlike the original analysis, economic optimization increases "
    f"peak losses by {f('sano_peak_loss_change_pct', 1)}%, "
    f"{f('kudamatsu_peak_loss_change_pct', 1)}% and "
    f"{f('yasu_peak_loss_change_pct', 1)}%, because smaller conductors remain "
    "within the frozen engineering gates. Broad parameter and reconstruction "
    "uncertainty is propagated without reoptimizing equipment in each draw. "
    "The results support a conditional planning claim: renewal screening can "
    "identify positive modeled savings, but the benefit is primarily an "
    "equipment-sizing result and is not evidence of observed utility topology "
    "or a construction-ready design.")
doc.add_paragraph(abstract)
doc.add_paragraph(
    "Keywords: distribution planning; undergrounding; life-cycle cost; "
    "conductor sizing; Steiner tree; voltage feasibility; reconstruction "
    "uncertainty")

doc.add_heading("1. Introduction", 1)
p = doc.add_paragraph(
    "Renewal of overhead distribution assets creates a planning choice: "
    "reproduce an incumbent or reconstructed corridor underground, or evaluate "
    "alternative radial routes and equipment before construction. Underground "
    "cables can improve amenity and reduce exposure to some external hazards, "
    "but their capital and repair characteristics make life-cycle screening "
    "important. ")
cite(p, D["under"])
p.add_run(
    " Distribution-planning research has long represented topology, "
    "reconfiguration and conductor allocation as decision variables. ")
cite(p, D["baran_rec"])
p.add_run(" ")
cite(p, D["ga_dnp"])
p.add_run(
    " The narrower renewal question remains difficult when utility topology "
    "and equipment records are unavailable to an external analyst.")

p = doc.add_paragraph(
    "The canonical analysis motivating this reanalysis reported large voltage "
    "drops and simultaneously interpreted relative cost and loss differences. "
    "A forensic audit showed that aggregate feeder demand had been evaluated "
    "on a 415-V representation without an explicit medium-voltage primary, "
    "transformers, reactive power, transformer losses or binding feasibility "
    "gates. Some disconnected road components were also combined during "
    "clustering, allowing demand to disappear from downstream topology files. "
    "Those issues make the original voltage and loss claims unsuitable for "
    "engineering inference. The present study therefore asks a stricter "
    "question: after repairing the smallest defensible electrical and "
    "reconstruction defects, do positive S1–S2 life-cycle savings remain, and "
    "which decision layer produces them?")

p = doc.add_paragraph(
    "The contribution is fourfold. First, we state a frozen engineering "
    "boundary from the primary source to equivalent customer service and "
    "exclude infeasible candidates. Second, we distinguish municipal "
    "observations from reconstructed network objects. Third, we validate the "
    "radial calculation quantitatively against independent AC power-flow "
    "solutions rather than treating solver convergence as validation. Fourth, "
    "we use a factorial ablation to separate routing/topology and conductor "
    "sizing, with their interaction reported explicitly. The analysis is a "
    "planning experiment, not a reconstruction of any municipality's actual "
    "utility network.")

doc.add_heading("2. Data and methods", 1)
doc.add_heading("2.1 Observed data, modeled demand and evidence tiers", 2)
p = doc.add_paragraph(
    "Roads and building footprints were obtained from OpenStreetMap, whose "
    "collaborative geographic-data model is documented elsewhere. ")
cite(p, D["osm"])
p.add_run(
    " Buildings define modeled demand geography; they do not reveal actual "
    "customer load, phase connection or transformer assignment. Municipal "
    "security-light inventories provide additional location evidence in Sano "
    "and Kudamatsu. Sano contains "
    f"{int(v('sano_observed_rows')):,} records with a pole-number field, but "
    "multiple records linked to one identifier frequently have different "
    "coordinates; record coordinates are therefore not asserted to be exact "
    "pole coordinates. Kudamatsu contains "
    f"{int(v('kudamatsu_observed_rows')):,} unique security-light identifiers, "
    "which are not pole identifiers. Yasu contributes no municipal pole or "
    "security-light inventory. None of these datasets observes conductor, "
    "transformer or feeder connectivity.")

doc.add_paragraph(
    "Positive modeled demand nodes were clustered only within connected "
    "components of the road graph, and singleton components were retained. "
    "This preserves all modeled demand. The resulting Sano, Kudamatsu and Yasu "
    f"study zones contain {int(v('sano_clusters'))}, "
    f"{int(v('kudamatsu_clusters'))} and "
    f"{int(v('yasu_clusters'))} clusters and "
    f"{v('sano_total_demand_kw')/1000:.2f}, "
    f"{v('kudamatsu_total_demand_kw')/1000:.2f} and "
    f"{v('yasu_total_demand_kw')/1000:.2f} MW of modeled peak "
    "demand, respectively (Figure 1 and Table 1).")

doc.add_heading("2.2 Reconstruction and scenario definitions", 2)
p = doc.add_paragraph(
    "For each non-singleton cluster, 24 radial reconstruction candidates were "
    "generated: 12 jittered, anchor-biased Steiner candidates and 12 shuffled "
    "incremental cheapest-attachment candidates. Steiner approximation is "
    "used as a tractable graph heuristic rather than a proof of a globally "
    "optimal utility layout. ")
cite(p, D["hwang"])
p.add_run(" ")
cite(p, D["kou"])
p.add_run(
    " Reconstruction convergence is assessed by repeating aggregate S1 "
    "estimation with increasing prefixes of both candidate families.")

doc.add_paragraph(
    "S0 denotes the reconstructed legacy overhead route. S1 places reference "
    "underground conductors on each S0 route and is the like-for-like "
    "benchmark. S1.5 is the minimum-construction Steiner route. S2 selects "
    "among weighted Steiner candidates and sizes conductors to minimize modeled "
    "net present cost subject to the engineering gates. Figure 2 illustrates "
    "one reconstruction and one S2 candidate. Route difference is reported as "
    "Jaccard edge-set divergence, not as a likelihood:")
equation("D_edge = 1 − |E_S1 ∩ E_S2| / |E_S1 ∪ E_S2|")

doc.add_heading("2.3 Electrical hierarchy and feasibility gates", 2)
doc.add_paragraph(
    f"The frozen model uses a {spec['system']['mv_nominal_kv']:.1f}-kV "
    f"three-phase primary, {spec['system']['lv_nominal_v']}-V secondary and "
    f"{spec['system']['lv_service_nominal_v']}-V single-phase customer-service "
    f"reference at power factor {spec['system']['power_factor']:.2f}. Sano is "
    f"evaluated at {v('sano_frequency_hz'):.0f} Hz; Kudamatsu and Yasu at "
    f"{v('kudamatsu_frequency_hz'):.0f} Hz. Cable reactance is scaled "
    "linearly from the catalogue reference frequency, and frequency-matched "
    "transformer rows are selected. A transformer is placed at every "
    "road-snapped demand node. Loads above "
    f"{spec['topology_gates']['max_lv_unit_kw']:.0f} kW are split into parallel "
    "service units; each unit has an equivalent "
    f"{spec['topology_gates']['modeled_lv_stub_length_m']:.0f}-m LV stub. These "
    "are explicit planning approximations because customer-level secondary "
    "geometry is unavailable.")

doc.add_paragraph(
    "Balanced radial active and reactive flows are propagated from a 1.0-pu "
    "source. For an edge with line-line sending voltage V, downstream apparent "
    "power S and conductor impedance R+jX, current and approximate voltage "
    "change are:")
equation("I = S / (√3 V)")
equation("ΔV_LL = √3 I (R cos φ + X sin φ)")
p = doc.add_paragraph(
    "This is a transparent radial approximation related to established "
    "distribution-flow formulations. ")
cite(p, D["baran_cap"])
p.add_run(" ")
cite(p, D["linopf"])
p.add_run(
    " Conductors are selected from archived catalogues with buried-duct "
    "ampacity derating. Transformers are chosen from frequency-matched "
    "catalogue rows at no more than 80% design loading; catalogue no-load and "
    "load losses are included.")

doc.add_paragraph(
    f"Primary voltage drop must not exceed "
    f"{spec['voltage_gates']['mv_drop_max_pct']:.1f}%, transformer drop "
    f"{spec['voltage_gates']['transformer_drop_max_pct']:.1f}% and equivalent "
    f"LV drop {spec['voltage_gates']['lv_drop_max_pct']:.1f}%. Customer voltage "
    f"must remain between "
    f"{spec['voltage_gates']['customer_min_pu_on_105v']:.3f} and "
    f"{spec['voltage_gates']['customer_max_pu_on_105v']:.3f} pu. Cable and transformer "
    "loading must not exceed 100%. Connectivity, radiality, complete demand "
    "service and power-balance checks are mandatory. A candidate failing any "
    "gate is ineligible for headline comparison; no voltage clipping or limit "
    "relaxation is used.")

doc.add_heading("2.4 Life-cycle objective and ablation", 2)
doc.add_paragraph(
    "Capital cost contains trench/duct, conductor and transformer components. "
    "Annual cost contains O&M, variable conductor and transformer load losses, "
    "and transformer no-load losses. For horizon h and real discount rate r:")
equation("NPC = C_cap + [C_cap f_OM + E_loss p_e] Σ_(t=1)^h (1+r)^(−t)")
doc.add_paragraph(
    f"The base case uses {config['project']['primary_horizon_years']} years and "
    f"a {100*config['project']['discount_rate']:.0f}% discount rate. Cost inputs "
    "are scenario assumptions rather than observed bids or regulated tariffs; "
    "their low-confidence provenance and broad uncertainty ranges are reported "
    "in COST_PARAMETER_PROVENANCE.csv. The primary metric is:")
equation("LTP(%) = 100 [NPC(S1) − NPC(S2)] / NPC(S1)")

doc.add_paragraph(
    "A 2×2 factorial ablation evaluates fixed versus optimized routing and "
    "fixed versus optimized conductor sizing. Shapley averaging reports each "
    "decision's marginal contribution across both orderings, and the residual "
    "topology–conductor interaction is retained. Transformer configuration is "
    "held common in this ablation; zero transformer variation is therefore a "
    "design condition, not evidence that transformer decisions lack value.")

doc.add_heading("2.5 Validation and uncertainty", 2)
p = doc.add_paragraph(
    "The corrected radial calculation was compared with pandapower AC "
    "power-flow solutions ")
cite(p, D["pandapower"])
p.add_run(
    " for three radial feeders extracted from the CIGRE low-voltage benchmark. "
    "Tolerances were declared before comparison: maximum absolute minimum-"
    "voltage error of 0.003 pu and relative line-loss error of 10%. Newton–"
    "Raphson, backward/forward sweep and Iwamoto Newton–Raphson solutions were "
    "also cross-checked. The separate case11_iwamoto network did not converge "
    "under those three solvers and is excluded from the validation claim; "
    "nonconvergence is not interpreted as validation or statutory compliance.")

doc.add_paragraph(
    f"Uncertainty uses {sensitivity_config['n_mc']:,} draws over reconstruction "
    f"candidate, excavation/construction cost "
    f"({sensitivity_ranges['construction_multiplier'][0]:.1f}–"
    f"{sensitivity_ranges['construction_multiplier'][1]:.1f}×), conductor "
    f"cost ({sensitivity_ranges['conductor_multiplier'][0]:.1f}–"
    f"{sensitivity_ranges['conductor_multiplier'][1]:.1f}×), transformer cost "
    f"({sensitivity_ranges['transformer_multiplier'][0]:.1f}–"
    f"{sensitivity_ranges['transformer_multiplier'][1]:.1f}×), electricity "
    f"value ({sensitivity_ranges['electricity_jpy_per_kwh'][0]:g}–"
    f"{sensitivity_ranges['electricity_jpy_per_kwh'][1]:g} JPY/kWh), O&M "
    f"fraction ({100*sensitivity_ranges['om_fraction'][0]:.1f}–"
    f"{100*sensitivity_ranges['om_fraction'][1]:.1f}%/year), discount rate "
    f"({100*sensitivity_ranges['discount_rate'][0]:g}–"
    f"{100*sensitivity_ranges['discount_rate'][1]:g}%), horizon "
    f"({'/'.join(map(str, sensitivity_ranges['horizon_years']))} years), load "
    f"factor ({sensitivity_ranges['load_factor'][0]:.2f}–"
    f"{sensitivity_ranges['load_factor'][1]:.2f}) and coincident demand "
    f"multiplier ({sensitivity_ranges['demand_multiplier'][0]:.2f}–"
    f"{sensitivity_ranges['demand_multiplier'][1]:.2f}). S2 "
    "topology and equipment are not reoptimized or resized in each draw; this "
    "is parameter uncertainty around the frozen design, not stochastic "
    "reoptimization.")

doc.add_heading("3. Results", 1)
doc.add_heading("3.1 Engineering feasibility and benchmark agreement", 2)
doc.add_paragraph(
    "All primary S1 and S2 networks entering the comparison passed the frozen "
    "connectivity, radiality, demand-service, voltage, thermal and power-balance "
    "gates. Across municipalities, the maximum modeled MV drop was "
    f"{max(v(f'{city}_max_mv_vdrop_pct') for city in ['sano', 'kudamatsu', 'yasu']):.2f}% "
    "and the minimum equivalent customer voltage was "
    f"{min(v(f'{city}_min_customer_voltage_pu') for city in ['sano', 'kudamatsu', 'yasu']):.4f} "
    "pu (Table 2). "
    "These values replace the original 29–38% drops, which resulted from both "
    "implementation and structural modeling defects rather than from feasible "
    "primary networks.")
doc.add_paragraph(
    f"All {int(v('benchmark_feeders_validated'))} CIGRE radial feeders passed "
    "the predeclared comparison. Maximum minimum-voltage error was "
    f"{f('benchmark_max_voltage_error_pu', 6)} pu and maximum relative line-"
    f"loss error was {100*v('benchmark_max_loss_relative_error'):.2f}%. "
    "Agreement supports use of the approximation within this study's balanced "
    "radial boundary; it does not validate unbalanced operation, protection, "
    "fault duty, harmonics or transient behavior.")

doc.add_heading("3.2 Corrected life-cycle results", 2)
doc.add_paragraph(
    "S2 lowers modeled NPC relative to S1 by "
    f"{bn(v('sano_delta_npc'))}, "
    f"{bn(v('kudamatsu_delta_npc'))} and "
    f"{bn(v('yasu_delta_npc'))} billion JPY, equivalent to "
    f"{f('sano_ltp_pct',1)}%, {f('kudamatsu_ltp_pct',1)}% and "
    f"{f('yasu_ltp_pct',1)}% for Sano, Kudamatsu and Yasu (Table 2; Figure 3). "
    "Thus, positive modeled savings survive repair, but the corrected "
    "percentages differ materially from the quarantined original results.")

doc.add_paragraph(
    "The direction of the loss result reverses. S2 peak loss changes by "
    f"{f('sano_peak_loss_change_pct',1)}%, "
    f"{f('kudamatsu_peak_loss_change_pct',1)}% and "
    f"{f('yasu_peak_loss_change_pct',1)}% relative to S1. The NPC objective "
    "selects smaller conductors that remain feasible because the discounted "
    "value of additional loss is lower than the avoided conductor cost under "
    "the base assumptions. The corrected study therefore provides no support "
    "for the original claim that optimized networks roughly halve peak loss.")

doc.add_heading("3.3 Decision attribution and uncertainty", 2)
doc.add_paragraph(
    "Shapley attribution assigns routing/topology savings of "
    f"{bn(v('sano_topology_shapley_savings_jpy'))}, "
    f"{bn(v('kudamatsu_topology_shapley_savings_jpy'))} and "
    f"{bn(v('yasu_topology_shapley_savings_jpy'))} billion "
    "JPY, compared with conductor-sizing savings of "
    f"{bn(v('sano_conductor_shapley_savings_jpy'))}, "
    f"{bn(v('kudamatsu_conductor_shapley_savings_jpy'))} and "
    f"{bn(v('yasu_conductor_shapley_savings_jpy'))} billion "
    "JPY (Figure 4 and Table 3). Consequently, the corrected economic result "
    "is predominantly equipment-sizing value, not a large route-topology "
    "effect.")

doc.add_paragraph(
    "Across the broad uncertainty design, mean LTP is "
    f"{v('sano_mc_ltp_pct_mean'):.2f}%, "
    f"{v('kudamatsu_mc_ltp_pct_mean'):.2f}% and "
    f"{v('yasu_mc_ltp_pct_mean'):.2f}%. The corresponding 95% "
    "intervals are "
    f"[{v('sano_mc_ltp_pct_p2_5'):.2f}, "
    f"{v('sano_mc_ltp_pct_p97_5'):.2f}]%, "
    f"[{v('kudamatsu_mc_ltp_pct_p2_5'):.2f}, "
    f"{v('kudamatsu_mc_ltp_pct_p97_5'):.2f}]% and "
    f"[{v('yasu_mc_ltp_pct_p2_5'):.2f}, "
    f"{v('yasu_mc_ltp_pct_p97_5'):.2f}]%; P(LTP>0) is "
    f"{v('sano_mc_p_ltp_pos'):.3f}, "
    f"{v('kudamatsu_mc_p_ltp_pos'):.3f} and "
    f"{v('yasu_mc_p_ltp_pos'):.3f}, respectively (Figure 3 and "
    "Table 4). These are probabilities under the declared sampling design, not "
    "frequentist confidence that a real project will save money.")

doc.add_heading("4. Discussion", 1)
doc.add_paragraph(
    "The principal result is narrower and more useful than the original "
    "headline. An engineering-feasible positive S1–S2 cost difference remains "
    "in the three modeled zones, but most value arises from conductor sizing. "
    "Route reconsideration contributes a smaller positive amount. This "
    "distinction changes the practical screening question: before undertaking "
    "a complex rerouting exercise, planners should verify that like-for-like "
    "renewal has not inherited an uneconomic conductor standard. Topology "
    "screening can then target clusters where the incremental route value "
    "exceeds survey, easement and implementation costs omitted from the graph "
    "model.")

p = doc.add_paragraph(
    "This interpretation is consistent with classical conductor-selection "
    "work, which trades installed cost against discounted losses. ")
cite(p, D["condsel"])
p.add_run(
    " It also explains the apparently counter-intuitive increase in S2 loss: "
    "an economic optimum need not be a loss minimum. Engineering constraints "
    "define admissibility, while the objective chooses among admissible "
    "designs. If decarbonization, capacity headroom or reliability were "
    "assigned additional value, larger conductors could become optimal.")

doc.add_paragraph(
    "Several limitations prevent transfer of the numerical estimates to a "
    "construction decision. First, the networks are reconstructed from roads, "
    "buildings and limited light-inventory anchors; no actual feeder, phase, "
    "switch, cable, transformer or customer-load records were available. "
    "Second, demand magnitudes and simultaneity are modeled. Third, the "
    "equivalent 25-m LV stub and 60-kW service-unit cap simplify unavailable "
    "customer-level secondary geometry. Fourth, balanced radial steady-state "
    "calculations omit phase imbalance, contingency restoration, protection, "
    "fault current, reliability and construction staging. Fifth, weighted "
    "Steiner candidates do not prove global optimality. Sixth, cost inputs are "
    "low-confidence assumptions without project-specific quotations. Seventh, "
    "uncertainty draws evaluate a frozen S2 design rather than reoptimizing "
    "topology and equipment. Finally, the ablation intentionally holds "
    "transformer configuration common.")

doc.add_paragraph(
    "A rooftop-photovoltaic scenario from the canonical package is not retained "
    "as a corrected headline result. Available building footprints do not "
    "establish roof suitability, ownership, hourly generation, hosting "
    "capacity, curtailment, export compensation or reinforcement requirements. "
    "A defensible extension requires time-series load and irradiance, "
    "unbalanced hosting-capacity analysis and explicit commercial assumptions.")

doc.add_paragraph(
    "Future work should use utility-provided topology and interval load where "
    "available, solve a jointly reoptimized stochastic design, include "
    "reliability and resilience benefits, obtain local construction bids, and "
    "model unbalanced multi-period operation. Prospective validation should "
    "compare recommended and actual designs without using municipal light "
    "inventories as a proxy for complete utility assets.")

doc.add_heading("5. Conclusions", 1)
doc.add_paragraph(
    "Repairing the electrical hierarchy, demand preservation, feasibility "
    "gates and benchmark interpretation changes the scientific conclusion. "
    "Positive modeled life-cycle savings remain for S2 relative to S1 in the "
    "three study zones, but the effect is smaller than the original headline "
    "in two zones, is dominated by conductor sizing, and does not reduce peak "
    "loss. The method is suitable for transparent early-stage screening under "
    "explicit assumptions. It is not evidence of observed municipal feeder "
    "topology and not a substitute for utility data or detailed engineering.")

doc.add_heading("Declarations", 1)
doc.add_paragraph(
    "Funding: none. Conflict of interest: none declared. Ethics approval: not "
    "applicable; the study uses public infrastructure and geographic data and "
    "contains no human participants or personal data.")
doc.add_paragraph(
    "Data and code availability: archived raw public-data snapshots, source "
    "URLs, retrieval metadata, checksums, processing scripts, machine-readable "
    "results and reproduction instructions accompany the submission package. "
    "Observed, reconstructed, modeled, assumed and sensitivity quantities are "
    "labeled separately.")
doc.add_paragraph(
    "Declaration of generative AI: during preparation, the authors used an AI "
    "coding assistant for code review, reproducibility checks and drafting. "
    "The authors reviewed and edited all outputs and take responsibility for "
    "the work.")

doc.add_heading("Figure captions", 1)
for caption in [
    "Figure 1. Study zones: OpenStreetMap road graph (grey) and road-snapped "
    "modeled building-demand nodes (blue).",
    "Figure 2. Example Sano cluster showing one S1 reconstruction replicate "
    "and the selected S2 candidate. Neither is asserted to be observed utility "
    "topology.",
    "Figure 3. Base-case and uncertainty-distribution S1–S2 net-present-cost "
    "difference. Error bars show the 2.5th and 97.5th percentiles.",
    "Figure 4. Shapley attribution of modeled S1–S2 savings to route/topology "
    "and conductor sizing. Transformer configuration is held common."]:
    doc.add_paragraph(caption)

doc.add_heading("Table 1. Evidence and modeled-study-zone summary", 1)
table = doc.add_table(rows=4, cols=5)
table.style = "Table Grid"
headers = ["Municipality", "Municipal evidence", "Observed records",
           "Modeled clusters", "Modeled demand (MW)"]
for i, text in enumerate(headers):
    table.rows[0].cells[i].text = text
for j, city in enumerate(["sano", "kudamatsu", "yasu"], 1):
    table.rows[j].cells[0].text = city.capitalize()
    table.rows[j].cells[1].text = values[f"{city}_evidence_tier"]
    table.rows[j].cells[2].text = str(int(v(f"{city}_observed_rows")))
    table.rows[j].cells[3].text = str(int(v(f"{city}_clusters")))
    table.rows[j].cells[4].text = (
        f"{v(f'{city}_total_demand_kw')/1000:.2f}")

for title, filename in [
    ("Table 2. Corrected scenario and engineering results",
     "table2_corrected_results.csv"),
    ("Table 3. Topology and conductor-sizing ablation", "table4_ablation.csv"),
    ("Table 4. Parameter and reconstruction uncertainty",
     "table3_uncertainty.csv")]:
    doc.add_heading(title, 1)
    frame = pd.read_csv(f"{ROOT}/tables/{filename}")
    table = doc.add_table(rows=len(frame) + 1, cols=len(frame.columns))
    table.style = "Table Grid"
    for i, heading in enumerate(frame.columns):
        table.rows[0].cells[i].text = str(heading)
    for row_index, (_, row) in enumerate(frame.iterrows(), 1):
        for column_index, heading in enumerate(frame.columns):
            item = row[heading]
            table.rows[row_index].cells[column_index].text = (
                f"{item:.5g}" if isinstance(item, float) else str(item))

doc.add_heading("References", 1)
for number, doi in enumerate(cite_order, 1):
    ref = ref_by_doi[doi]
    authors = ref["authors"].replace("; ", ", ")
    doc.add_paragraph(
        f"[{number}] {authors}. {ref['title']}. {ref['container']} "
        f"{ref['volume']}({ref['issue']}) {ref['pages']} ({ref['year']}). "
        f"doi:{ref['doi']}")

os.makedirs(f"{ROOT}/manuscript", exist_ok=True)
path = f"{ROOT}/manuscript/manuscript_corrected.docx"
doc.save(path)
word_count = len(" ".join(p.text for p in doc.paragraphs).split())
abstract_words = len(abstract.split())
print("saved", path, "words", word_count, "abstract", abstract_words,
      "references", len(cite_order))
