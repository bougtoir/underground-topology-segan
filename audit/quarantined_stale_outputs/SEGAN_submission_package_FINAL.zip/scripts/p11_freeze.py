"""Freeze every manuscript value from final machine-readable outputs."""
import os

import pandas as pd
import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
scen = pd.read_csv(f"{ROOT}/analysis/scenario_results.csv")
mc = pd.read_csv(f"{ROOT}/analysis/sensitivity_mc.csv")
audit = pd.read_csv(f"{ROOT}/MUNICIPAL_DATA_PROVENANCE_AUDIT.csv")
bench = pd.read_csv(f"{ROOT}/analysis/benchmark_radial_comparison.csv")
conv = pd.read_csv(
    f"{ROOT}/analysis/reconstruction_convergence_summary.csv")
decomp = pd.read_csv(f"{ROOT}/analysis/ablation_decomposition.csv")
spec = yaml.safe_load(open(
    f"{ROOT}/ENGINEERING_FEASIBILITY_SPEC.yaml", encoding="utf-8"))

rows = []


def add(key, value, unit, source, label):
    rows.append(dict(key=key, value=value, unit=unit, source=source,
                     epistemic_label=label))


for _, r in scen.iterrows():
    city = r.city
    fields = {
        "clusters": ("count", "modeled"),
        "total_demand_kw": ("kW", "modeled"),
        "s1_npc": ("JPY", "modeled"),
        "s2_npc": ("JPY", "modeled"),
        "delta_npc": ("JPY", "modeled"),
        "ltp_pct": ("%", "modeled"),
        "s1_plkw": ("kW", "modeled"),
        "s2_plkw": ("kW", "modeled"),
        "max_mv_vdrop_pct": ("%", "modeled"),
        "min_customer_voltage_pu": ("pu", "modeled"),
        "mean_edge_set_divergence": ("fraction", "modeled"),
    }
    for field, (unit, label) in fields.items():
        add(f"{city}_{field}", r[field], unit,
            "analysis/scenario_results.csv", label)
    add(f"{city}_peak_loss_change_pct",
        100.0 * (r.s2_plkw / r.s1_plkw - 1.0), "%",
        "analysis/scenario_results.csv", "modeled")
    add(f"{city}_frequency_hz",
        spec["system"]["municipality_frequency_hz"][city], "Hz",
        "ENGINEERING_FEASIBILITY_SPEC.yaml", "assumed engineering parameter")

for _, r in mc.iterrows():
    city = r.city
    for field, unit in [
        ("delta_mean", "JPY"), ("delta_median", "JPY"),
        ("delta_p2_5", "JPY"), ("delta_p97_5", "JPY"),
        ("ltp_pct_mean", "%"), ("ltp_pct_p2_5", "%"),
        ("ltp_pct_p97_5", "%"), ("p_ltp_pos", "probability"),
        ("n_draws", "draws"),
    ]:
        add(f"{city}_mc_{field}", r[field], unit,
            "analysis/sensitivity_mc.csv", "sensitivity")

for _, r in decomp.iterrows():
    city = r.city
    for field in ["topology_shapley_savings_jpy",
                  "conductor_shapley_savings_jpy",
                  "topology_conductor_interaction_jpy",
                  "transformer_variation_savings_jpy"]:
        add(f"{city}_{field}", r[field], "JPY",
            "analysis/ablation_decomposition.csv", "modeled")

for _, r in audit.iterrows():
    city = r.municipality.lower()
    add(f"{city}_observed_rows", r.rows, "records",
        "MUNICIPAL_DATA_PROVENANCE_AUDIT.csv", "observed")
    add(f"{city}_evidence_tier", r.evidence_tier, "",
        "MUNICIPAL_DATA_PROVENANCE_AUDIT.csv", "observed")

add("benchmark_max_voltage_error_pu", bench.voltage_abs_error_pu.max(), "pu",
    "analysis/benchmark_radial_comparison.csv", "benchmark")
add("benchmark_max_loss_relative_error", bench.loss_relative_error.max(),
    "fraction", "analysis/benchmark_radial_comparison.csv", "benchmark")
add("benchmark_feeders_validated", int(bench.validated.sum()), "count",
    "analysis/benchmark_radial_comparison.csv", "benchmark")

for _, r in conv.iterrows():
    add(f"{r.city}_reconstruction_last_change_pp",
        r.last_increment_change_percentage_points, "percentage points",
        "analysis/reconstruction_convergence_summary.csv", "diagnostic")

out = pd.DataFrame(rows)
out.to_csv(f"{ROOT}/FINAL_MANUSCRIPT_VALUES.csv", index=False)
out.to_csv(f"{ROOT}/analysis/manuscript_values.csv", index=False)
print(len(out), "values frozen")
