"""Create original-versus-corrected and interaction-aware ablation outputs."""
import os

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def add(rows, city, metric, original, corrected, reason, interpretation):
    if isinstance(original, (int, float)) and isinstance(corrected, (int, float)):
        change = corrected - original
    else:
        change = ""
    rows.append(dict(
        Municipality=city.title(), Metric=metric, Original=original,
        Corrected=corrected, Change=change, Reason=reason,
        Interpretation=interpretation))


original = pd.read_csv(f"{ROOT}/audit/original_results/scenario_results.csv").set_index("city")
corrected = pd.read_csv(f"{ROOT}/analysis/scenario_results.csv").set_index("city")
rows = []
for city in corrected.index:
    old = original.loc[city]
    new = corrected.loc[city]
    add(rows, city, "modeled demand (kW)", old.total_demand_kw,
        new.total_demand_kw,
        "Demand is unchanged; disconnected road components are now clustered separately.",
        "The correction changes electrical representation, not modeled demand.")
    add(rows, city, "feeder/service clusters", old.clusters, new.clusters,
        "Clustering is constrained within connected road-graph components and retains singletons.",
        "No demand cluster is silently discarded because its road subgraph is disconnected.")
    add(rows, city, "S1 NPC (JPY)", old.s1_npc, new.s1_npc,
        "Corrected NPC includes explicit transformers, equivalent LV services, catalogued cables and losses.",
        "Absolute NPC is not directly comparable to the incomplete legacy boundary.")
    add(rows, city, "S2 NPC (JPY)", old.s2_npc, new.s2_npc,
        "Corrected NPC includes the same complete MV/LV/transformer boundary as S1.",
        "Absolute NPC is higher because omitted assets were restored.")
    add(rows, city, "S1-S2 NPC difference (JPY)", old.delta_npc, new.delta_npc,
        "Recomputed after enforcing engineering feasibility and complete asset boundaries.",
        "Positive savings survive, but their magnitude changes.")
    add(rows, city, "life-cycle topology potential (%)", old.ltp_pct, new.ltp_pct,
        "Recomputed with 6.6 kV primary feeders, explicit transformers, P/Q flow and feasibility gates.",
        "The original headline percentage is not robust; the corrected estimate is smaller for Sano and Yasu.")
    old_loss_reduction = 100.0 * (old.s1_plkw - old.s2_plkw) / old.s1_plkw
    new_loss_reduction = 100.0 * (new.s1_plkw - new.s2_plkw) / new.s1_plkw
    add(rows, city, "peak-loss reduction S1 to S2 (%)",
        old_loss_reduction, new_loss_reduction,
        "Corrected conductor choice minimizes NPC under ampacity/voltage gates rather than forcing a loss-minimizing outcome.",
        "The corrected best-NPC designs use smaller feasible conductors and have higher peak loss; the original 60-65% loss-reduction claim fails.")
    add(rows, city, "maximum primary voltage drop (%)", old.max_vdrop,
        new.max_mv_vdrop_pct,
        "The legacy calculation applied a 415 V base to aggregated cluster routes; corrected routes are 6.6 kV primary feeders.",
        "The 29-38% values were structural/model artifacts, not feasible-network diagnostics.")
    add(rows, city, "minimum customer voltage (pu)", "", new.min_customer_voltage_pu,
        "New metric combines MV, transformer and equivalent LV-service drop.",
        "All headline S1 and S2 networks pass the frozen statutory/planning gate.")
    add(rows, city, "transformer units", "", new.transformer_units,
        "Explicit catalogued transformer units are sized at <=80% design loading.",
        "Transformer count is now visible in engineering and cost boundaries.")
    add(rows, city, "edge-set divergence", old.mean_tld,
        new.mean_edge_set_divergence,
        "The metric is renamed from TLD because it is a Jaccard edge-set distance, not a likelihood.",
        "The corrected candidate family often selects the minimum-construction topology; routing changes are modest.")

pd.DataFrame(rows).to_csv(f"{ROOT}/ORIGINAL_VS_CORRECTED_RESULTS.csv", index=False)

ablation = pd.read_csv(f"{ROOT}/analysis/ablation_results.csv")
pivot = (ablation.groupby(["city", "ablation"]).npc_jpy.sum()
         .unstack("ablation"))
decomposition = []
for city, row in pivot.iterrows():
    f00 = row["topology_fixed_conductor_fixed"]
    f01 = row["topology_fixed_conductor_optimized"]
    f10 = row["topology_optimized_conductor_fixed"]
    f11 = row["topology_optimized_conductor_optimized"]
    topology_first = f00 - f10
    topology_after_conductor = f01 - f11
    conductor_first = f00 - f01
    conductor_after_topology = f10 - f11
    topology_shapley = 0.5 * (topology_first + topology_after_conductor)
    conductor_shapley = 0.5 * (conductor_first + conductor_after_topology)
    interaction = (f00 - f10 - f01 + f11)
    decomposition.append(dict(
        city=city, npc_topology_fixed_conductor_fixed=f00,
        npc_topology_fixed_conductor_optimized=f01,
        npc_topology_optimized_conductor_fixed=f10,
        npc_topology_optimized_conductor_optimized=f11,
        total_savings_jpy=f00 - f11,
        topology_shapley_savings_jpy=topology_shapley,
        conductor_shapley_savings_jpy=conductor_shapley,
        topology_conductor_interaction_jpy=interaction,
        transformer_variation_savings_jpy=0.0,
        decomposition_check_jpy=topology_shapley + conductor_shapley
        - (f00 - f11)))
pd.DataFrame(decomposition).to_csv(
    f"{ROOT}/analysis/ablation_decomposition.csv", index=False)
print(pd.DataFrame(decomposition).to_string(index=False))
