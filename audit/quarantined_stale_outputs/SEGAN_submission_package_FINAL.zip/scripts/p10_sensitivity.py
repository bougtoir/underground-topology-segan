"""Phases 9-10: corrected global uncertainty and sensitivity analysis.

Each draw samples one feasible S1 reconstruction per cluster and varies
discount rate, horizon, electricity value, O&M, trench/construction cost,
conductor cost, transformer cost, load factor and demand. S2 topology and
discrete equipment choices remain fixed at the base-case best feasible design;
this limitation is recorded in every output.
"""
import os

import numpy as np
import pandas as pd
import yaml

from electrical_model import loss_factor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = yaml.safe_load(open(f"{ROOT}/config/study.yaml", encoding="utf-8"))
SEED = CFG["project"]["seed"]
N = CFG["sensitivity"]["n_mc"]
RANGES = CFG["sensitivity"]["ranges"]
BASE_LF = CFG["project"]["load_factor"]
BASE = dict(
    discount_rate=CFG["project"]["discount_rate"],
    horizon=CFG["project"]["primary_horizon_years"],
    electricity_jpy_kwh=CFG["cost_model"]["electricity_jpy_per_kwh"],
    om_fraction=CFG["cost_model"]["om_fraction_of_capex"],
    construction_multiplier=1.0, conductor_multiplier=1.0,
    transformer_multiplier=1.0, load_factor=BASE_LF,
    demand_multiplier=1.0)


def annuity_factor(rate, horizon):
    return sum(1.0 / (1.0 + rate) ** year
               for year in range(1, int(horizon) + 1))


def npc(components, params):
    capex = (
        components["trench"] * params["construction_multiplier"]
        + components["conductor"] * params["conductor_multiplier"]
        + components["transformer"] * params["transformer_multiplier"])
    variable_loss = (
        components["variable_loss"]
        * params["demand_multiplier"] ** 2
        * loss_factor(params["load_factor"]) / loss_factor(BASE_LF))
    annual_loss = variable_loss + components["no_load_loss"]
    return capex + (
        annual_loss * params["electricity_jpy_kwh"]
        + capex * params["om_fraction"]) * annuity_factor(
            params["discount_rate"], params["horizon"])


rng = np.random.default_rng(SEED)
draws = pd.DataFrame(dict(
    discount_rate=rng.uniform(*RANGES["discount_rate"], N),
    horizon=rng.choice(RANGES["horizon_years"], N),
    electricity_jpy_kwh=rng.uniform(
        *RANGES["electricity_jpy_per_kwh"], N),
    om_fraction=rng.uniform(*RANGES["om_fraction"], N),
    construction_multiplier=rng.uniform(
        *RANGES["construction_multiplier"], N),
    conductor_multiplier=rng.uniform(
        *RANGES["conductor_multiplier"], N),
    transformer_multiplier=rng.uniform(
        *RANGES["transformer_multiplier"], N),
    load_factor=rng.uniform(*RANGES["load_factor"], N),
    demand_multiplier=rng.uniform(*RANGES["demand_multiplier"], N)))
draws.insert(0, "draw", range(N))
draws.to_csv(f"{ROOT}/analysis/sensitivity_draws.csv", index=False)

diagnostics = pd.read_csv(f"{ROOT}/analysis/feasibility_diagnostics.csv")
diagnostics = diagnostics[
    (diagnostics.scenario == "S1") & diagnostics.feasible].copy()

mc_rows = []
tornado_rows = []
sampled_rows = []
for city in ["sano", "kudamatsu", "yasu"]:
    cluster = pd.read_csv(f"{ROOT}/data/processed/{city}/cluster_results.csv")
    legacy = diagnostics[diagnostics.city == city]
    grouped = {int(key): frame.reset_index(drop=True)
               for key, frame in legacy.groupby("cluster")}
    delta = np.empty(N)
    s1_values = np.empty(N)
    s2_values = np.empty(N)
    for draw_id, draw in draws.iterrows():
        params = draw.drop(labels="draw").to_dict()
        s1_total = 0.0
        s2_total = 0.0
        for _, result in cluster.iterrows():
            candidates = grouped[int(result.cluster)]
            selected_index = int(rng.integers(0, len(candidates)))
            selected = candidates.iloc[selected_index]
            s1_components = dict(
                trench=selected.capex_trench_jpy,
                conductor=selected.capex_conductor_jpy,
                transformer=selected.capex_transformer_jpy,
                variable_loss=selected.variable_loss_kwh_y,
                no_load_loss=selected.no_load_loss_kwh_y)
            s2_components = dict(
                trench=result.s2_capex_trench,
                conductor=result.s2_capex_conductor,
                transformer=result.s2_capex_transformer,
                variable_loss=result.s2_variable_loss_kwh_y,
                no_load_loss=result.s2_no_load_loss_kwh_y)
            s1_total += npc(s1_components, params)
            s2_total += npc(s2_components, params)
            sampled_rows.append(dict(
                city=city, draw=int(draw.draw), cluster=int(result.cluster),
                s1_candidate=selected.candidate))
        s1_values[draw_id] = s1_total
        s2_values[draw_id] = s2_total
        delta[draw_id] = s1_total - s2_total
    mc_rows.append(dict(
        city=city, n_draws=N, delta_mean=float(delta.mean()),
        delta_median=float(np.median(delta)),
        delta_p2_5=float(np.percentile(delta, 2.5)),
        delta_p5=float(np.percentile(delta, 5)),
        delta_p95=float(np.percentile(delta, 95)),
        delta_p97_5=float(np.percentile(delta, 97.5)),
        ltp_pct_mean=float(100.0 * np.mean(delta / s1_values)),
        ltp_pct_p2_5=float(100.0 * np.percentile(delta / s1_values, 2.5)),
        ltp_pct_p97_5=float(100.0 * np.percentile(delta / s1_values, 97.5)),
        p_ltp_pos=float(np.mean(delta > 0)),
        probability_resolution=1.0 / N,
        includes_reconstruction_uncertainty=True,
        topology_reoptimized_each_draw=False,
        equipment_resized_each_draw=False))

    base_components_s2 = dict(
        trench=float(cluster.s2_capex_trench.sum()),
        conductor=float(cluster.s2_capex_conductor.sum()),
        transformer=float(cluster.s2_capex_transformer.sum()),
        variable_loss=float(cluster.s2_variable_loss_kwh_y.sum()),
        no_load_loss=float(cluster.s2_no_load_loss_kwh_y.sum()))
    base_components_s1 = dict(
        trench=float(cluster.s1_capex_trench_mean.sum()),
        conductor=float(cluster.s1_capex_conductor_mean.sum()),
        transformer=float(cluster.s1_capex_transformer_mean.sum()),
        variable_loss=float(cluster.s1_variable_loss_kwh_y_mean.sum()),
        no_load_loss=float(cluster.s1_no_load_loss_kwh_y_mean.sum()))
    ranges = {
        "discount_rate": (0.01, 0.05),
        "horizon": (30, 50),
        "electricity_jpy_kwh": (15.0, 40.0),
        "om_fraction": (0.005, 0.025),
        "construction_multiplier": (0.5, 2.0),
        "conductor_multiplier": (0.6, 1.5),
        "transformer_multiplier": (0.7, 1.5),
        "load_factor": (0.25, 0.50),
        "demand_multiplier": (0.70, 1.00),
    }
    for parameter, limits in ranges.items():
        for level, value in zip(["low", "high"], limits):
            params = dict(BASE)
            params[parameter] = value
            s1_value = npc(base_components_s1, params)
            s2_value = npc(base_components_s2, params)
            tornado_rows.append(dict(
                city=city, parameter=parameter, level=level, value=value,
                delta_npc=s1_value - s2_value,
                ltp_pct=100.0 * (s1_value - s2_value) / s1_value))

pd.DataFrame(mc_rows).to_csv(
    f"{ROOT}/analysis/sensitivity_mc.csv", index=False)
pd.DataFrame(tornado_rows).to_csv(
    f"{ROOT}/analysis/sensitivity_tornado.csv", index=False)
# The selected-candidate trace is machine-readable but compacted to counts.
sample_counts = (pd.DataFrame(sampled_rows)
                 .groupby(["city", "cluster", "s1_candidate"])
                 .size().rename("selection_count").reset_index())
sample_counts.to_csv(
    f"{ROOT}/analysis/sensitivity_reconstruction_sampling.csv", index=False)
print(pd.DataFrame(mc_rows).to_string(index=False))
