"""Create corrected submission files, QC records, handoff and final ZIP."""
import csv
import datetime
import hashlib
import json
import os
import platform
import re
import subprocess
import zipfile

import pandas as pd
import yaml
from docx import Document

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NOW = datetime.datetime.now(datetime.timezone.utc).isoformat()
values = {r["key"]: r["value"] for r in csv.DictReader(
    open(f"{ROOT}/FINAL_MANUSCRIPT_VALUES.csv", encoding="utf-8"))}
scenario = pd.read_csv(f"{ROOT}/analysis/scenario_results.csv").set_index("city")
sensitivity = pd.read_csv(
    f"{ROOT}/analysis/sensitivity_mc.csv").set_index("city")
config = yaml.safe_load(open(f"{ROOT}/config/study.yaml", encoding="utf-8"))


def f(key, digits=1):
    return f"{float(values[key]):.{digits}f}"


os.makedirs(f"{ROOT}/manuscript", exist_ok=True)
highlights = [
    "Renewal alternatives pass explicit voltage, thermal and radiality gates",
    "Corrected life-cycle savings remain positive in three modeled study zones",
    "Conductor sizing contributes more modeled savings than route topology",
    "Economic optimization raises losses while remaining engineering-feasible",
    "Observed municipal data are separated from reconstructed network objects",
]
if not all(3 <= len(x) <= 85 for x in highlights):
    raise ValueError("highlight length outside Elsevier requirement")
open(f"{ROOT}/manuscript/highlights_corrected.txt", "w", encoding="utf-8").write(
    "\n".join(highlights) + "\n")

cover = f"""Dear Editor,

Please consider “Engineering-feasible life-cycle optimization for underground
distribution renewal: separating topology and conductor-sizing value under
reconstruction uncertainty” as an Original Research Article in Sustainable
Energy, Grids and Networks.

The manuscript presents a forensic reanalysis and corrected planning model.
It enforces an explicit MV/transformer/LV hierarchy, quantitative AC benchmark
comparison, complete demand preservation and binding engineering feasibility.
Positive modeled S1–S2 savings remain ({f('sano_ltp_pct')}%,
{f('kudamatsu_ltp_pct')}% and {f('yasu_ltp_pct')}%), but the corrected
interpretation is materially narrower: conductor sizing contributes more than
route topology, and peak losses increase rather than decrease. Original
outputs are quarantined and the complete correction trail is supplied.

The work is original, is not under consideration elsewhere, and has been
approved by all authors. Author and affiliation details will be completed
locally before submission.

Sincerely,
[Corresponding author]
"""
open(f"{ROOT}/manuscript/cover_letter_corrected.txt", "w",
     encoding="utf-8").write(cover)

declarations = """Funding: None.
Conflict of interest: None declared.
Ethics approval: Not applicable; no human participants or personal data.
Data and code availability: Raw public-data snapshots, source metadata,
checksums, scripts, machine-readable outputs and reproduction instructions
accompany the submission package.
Generative AI: The authors used an AI coding assistant for code review,
reproducibility checks and drafting. The authors reviewed and edited all
outputs and take responsibility for the work.
"""
open(f"{ROOT}/manuscript/declarations_corrected.txt", "w",
     encoding="utf-8").write(declarations)

os.makedirs(f"{ROOT}/municipality", exist_ok=True)
for city, japanese_name in [
        ("sano", "佐野市"), ("kudamatsu", "下松市"), ("yasu", "野洲市")]:
    summary = f"""# {japanese_name} planning-screening summary

This is a modeled research scenario, not an engineering design or a
reconstruction of the municipality's observed utility network.

- Modeled demand: {scenario.loc[city, 'total_demand_kw']/1000:.2f} MW
- Like-for-like S1 NPC: {scenario.loc[city, 's1_npc']/1e9:.2f} billion JPY
- Optimized S2 NPC: {scenario.loc[city, 's2_npc']/1e9:.2f} billion JPY
- Modeled S1-S2 difference: {scenario.loc[city, 'delta_npc']/1e9:.2f} billion JPY
  ({scenario.loc[city, 'ltp_pct']:.2f}% of S1)
- Maximum modeled MV drop: {scenario.loc[city, 'max_mv_vdrop_pct']:.2f}%
- Minimum equivalent customer voltage: {scenario.loc[city, 'min_customer_voltage_pu']:.4f} pu
- Uncertainty P(S1-S2 difference > 0): {sensitivity.loc[city, 'p_ltp_pos']:.3f}

The corrected analysis finds that conductor sizing contributes more modeled
savings than route topology. Project decisions require utility topology,
measured load, field survey, easement, reliability, protection and local bid
data that are unavailable in this study.
"""
    open(f"{ROOT}/municipality/{city}_planning_support_corrected.md", "w",
         encoding="utf-8").write(summary)

supp = Document()
supp.add_heading("Supplementary methods and forensic audit", 0)
supp.add_heading("S1. Scope", 1)
supp.add_paragraph(
    "This supplement documents the correction chain from canonical inputs to "
    "the engineering-feasible results. Original files remain byte-preserved "
    "under audit/originals and original numerical outputs are quarantined.")
for heading, filename in [
    ("S2. Voltage root-cause audit", "VOLTAGE_ROOT_CAUSE_AUDIT.md"),
    ("S3. Benchmark validation", "BENCHMARK_VALIDATION_REPORT.md")]:
    supp.add_heading(heading, 1)
    text = open(f"{ROOT}/{filename}", encoding="utf-8").read()
    for block in text.split("\n\n"):
        if block.strip():
            supp.add_paragraph(block.strip())
supp.add_heading("S4. Machine-readable supporting tables", 1)
for item in [
    "ORIGINAL_VS_CORRECTED_RESULTS.csv",
    "MUNICIPAL_DATA_PROVENANCE_AUDIT.csv",
    "COST_PARAMETER_PROVENANCE.csv",
    "RAW_DATA_ACQUISITION_REGISTRY.csv",
    "analysis/reconstruction_convergence.csv",
    "analysis/benchmark_radial_comparison.csv",
    "analysis/ablation_decomposition.csv",
    "analysis/sensitivity_mc.csv"]:
    supp.add_paragraph(item)
supp.save(f"{ROOT}/manuscript/supplement_corrected.docx")

claims = [
    ("All headline networks pass frozen feasibility gates",
     "analysis/scenario_results.csv; analysis/feasibility_diagnostics.csv",
     "modeled"),
    ("Corrected S1-S2 NPC savings are positive in all three zones",
     "analysis/scenario_results.csv:delta_npc,ltp_pct", "modeled"),
    ("Conductor sizing contributes more than route topology",
     "analysis/ablation_decomposition.csv", "modeled"),
    ("Corrected S2 peak losses exceed S1 peak losses",
     "analysis/scenario_results.csv:s1_plkw,s2_plkw", "modeled"),
    ("Three CIGRE radial feeders pass predeclared error tolerances",
     "analysis/benchmark_radial_comparison.csv", "benchmark"),
    ("case11_iwamoto is excluded after three solver failures",
     "analysis/benchmark_solver_crosscheck.csv; BENCHMARK_VALIDATION_REPORT.md",
     "benchmark"),
    ("Municipal datasets do not observe feeder connectivity",
     "MUNICIPAL_DATA_PROVENANCE_AUDIT.csv", "observed/provenance"),
    ("Cost inputs are scenario assumptions with broad uncertainty",
     "COST_PARAMETER_PROVENANCE.csv; analysis/sensitivity_mc.csv",
     "assumed/sensitivity"),
    ("S2 is not reoptimized within each uncertainty draw",
     "analysis/sensitivity_mc.csv:topology_reoptimized_each_draw",
     "sensitivity"),
]
pd.DataFrame(claims, columns=[
    "claim", "evidence_source", "epistemic_label"]).to_csv(
        f"{ROOT}/CLAIM_EVIDENCE_MATRIX.csv", index=False)

requirements = subprocess.run(
    [f"{ROOT}/.venv/bin/python", "-m", "pip", "freeze"],
    text=True, capture_output=True, check=True).stdout
environment = {
    "generated_utc": NOW,
    "python": platform.python_version(),
    "platform": platform.platform(),
    "packages": requirements.splitlines(),
}
json.dump(environment, open(f"{ROOT}/ENVIRONMENT_SNAPSHOT.json", "w"),
          indent=2)

reproduction = """# Corrected SEGAN reproduction

Use Python 3.12 and install `requirements.lock.txt` in an isolated environment.
Raw public inputs are preserved under `data/raw/`; canonical originals are
preserved under `audit/originals/`.

Run:

```bash
make final
```

The final target regenerates audits, reconstruction, corrected engineering
results, benchmark comparisons, uncertainty, frozen manuscript values,
figures, DOCX files, QC records and the final ZIP. Runtime is dominated by
24 reconstruction candidates per cluster and the engineering optimizer.
"""
open(f"{ROOT}/REPRODUCTION_CORRECTED.md", "w", encoding="utf-8").write(
    reproduction)

manifest = pd.read_csv(f"{ROOT}/audit/ORIGINALS_MANIFEST.csv")
original_checks = []
for _, row in manifest.iterrows():
    relative_path = f"audit/originals/{row['filename']}"
    path = f"{ROOT}/{relative_path}"
    digest = hashlib.sha256(open(path, "rb").read()).hexdigest()
    original_checks.append({
        "path": relative_path, "expected_sha256": row["expected_sha256"],
        "actual_sha256": digest, "pass": digest == row["expected_sha256"]})

manuscript = Document(f"{ROOT}/manuscript/manuscript_corrected.docx")
text = "\n".join(p.text for p in manuscript.paragraphs)
prohibited = [
    "topology likelihood distance", "roughly halved", "2.5–12%",
    "29–38% in the reconstructed networks"]
prohibited_hits = [term for term in prohibited if term.lower() in text.lower()]
numeric_keys = [
    "sano_ltp_pct", "kudamatsu_ltp_pct", "yasu_ltp_pct",
    "sano_peak_loss_change_pct", "kudamatsu_peak_loss_change_pct",
    "yasu_peak_loss_change_pct"]
numeric_checks = {
    key: f(key, 1) in text for key in numeric_keys}
all_artifacts = [
    "manuscript/manuscript_corrected.docx",
    "manuscript/manuscript_inline_corrected.docx",
    "manuscript/supplement_corrected.docx",
    "manuscript/cover_letter_corrected.txt",
    "manuscript/highlights_corrected.txt",
    "FINAL_MANUSCRIPT_VALUES.csv",
    "CLAIM_EVIDENCE_MATRIX.csv",
    "ORIGINAL_VS_CORRECTED_RESULTS.csv",
    "MUNICIPAL_DATA_PROVENANCE_AUDIT.csv",
    "COST_PARAMETER_PROVENANCE.csv",
    "RAW_DATA_ACQUISITION_REGISTRY.csv"]
artifact_checks = {path: os.path.exists(f"{ROOT}/{path}") for path in all_artifacts}
qc = {
    "generated_utc": NOW,
    "canonical_originals": original_checks,
    "all_canonical_originals_unchanged": all(x["pass"] for x in original_checks),
    "prohibited_legacy_claim_hits": prohibited_hits,
    "frozen_numeric_value_presence": numeric_checks,
    "required_artifacts": artifact_checks,
    "all_primary_networks_feasible": bool(
        scenario.all_primary_networks_feasible.all()),
    "sensitivity_draws_per_city": {
        city: int(sensitivity.loc[city, "n_draws"]) for city in scenario.index},
    "sensitivity_draw_count_pass": bool(
        (sensitivity.n_draws == config["sensitivity"]["n_mc"]).all()),
    "status": "pass",
}
if (not qc["all_canonical_originals_unchanged"] or prohibited_hits
        or not all(numeric_checks.values()) or not all(artifact_checks.values())
        or not qc["all_primary_networks_feasible"]
        or not qc["sensitivity_draw_count_pass"]):
    qc["status"] = "fail"
json.dump(qc, open(f"{ROOT}/FINAL_QC_MACHINE.json", "w"), indent=2)

report = f"""# Final QC report

- Generated: {NOW}
- Canonical originals unchanged: {qc['all_canonical_originals_unchanged']}
- Required artifacts present: {all(artifact_checks.values())}
- Frozen headline values found in manuscript: {all(numeric_checks.values())}
- Prohibited legacy claim hits: {prohibited_hits}
- All headline primary networks feasible: {qc['all_primary_networks_feasible']}
- Uncertainty draws per municipality: {min(qc['sensitivity_draws_per_city'].values())}
- Machine verdict: {qc['status']}

The clean-room and hostile-review gates are recorded separately and must pass
before the package is declared submission-ready.
"""
open(f"{ROOT}/FINAL_QC_REPORT.md", "w", encoding="utf-8").write(report)

handoff = f"""SEGAN forensic reanalysis final handoff
Generated: {NOW}
Corrected LTP: {f('sano_ltp_pct')}% / {f('kudamatsu_ltp_pct')}% /
{f('yasu_ltp_pct')}% (Sano/Kudamatsu/Yasu).
Scientific correction: positive modeled savings survive, but conductor sizing
dominates route topology and corrected S2 peak losses increase.
Canonical originals are unchanged. See FINAL_QC_MACHINE.json and
FINAL_QC_REPORT.md for gates.
"""
open(f"{ROOT}/FINAL_HANDOFF.txt", "w", encoding="utf-8").write(handoff)

include_roots = [
    "audit", "config", "data/raw", "data/processed/engineering", "scripts",
    "tests", "analysis", "figures", "tables", "manuscript", "provenance",
    "municipality"]
include_files = [
    "ENGINEERING_FEASIBILITY_SPEC.yaml", "VOLTAGE_ROOT_CAUSE_AUDIT.md",
    "BENCHMARK_VALIDATION_REPORT.md", "ORIGINAL_VS_CORRECTED_RESULTS.csv",
    "MUNICIPAL_DATA_PROVENANCE_AUDIT.csv", "COST_PARAMETER_PROVENANCE.csv",
    "RAW_DATA_ACQUISITION_REGISTRY.csv",
    "FINAL_MANUSCRIPT_VALUES.csv", "CLAIM_EVIDENCE_MATRIX.csv",
    "FINAL_QC_REPORT.md", "FINAL_QC_MACHINE.json", "FINAL_HANDOFF.txt",
    "ENVIRONMENT_SNAPSHOT.json", "REPRODUCTION_CORRECTED.md",
    "requirements.lock.txt", "Makefile"]
zip_path = f"{ROOT}/SEGAN_submission_package_FINAL.zip"
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
    for rel in include_files:
        archive.write(f"{ROOT}/{rel}", rel)
    for rel_root in include_roots:
        full_root = f"{ROOT}/{rel_root}"
        if not os.path.exists(full_root):
            continue
        for directory, dirs, files in os.walk(full_root):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for name in files:
                if name.endswith((".pyc", ".tmp")):
                    continue
                path = os.path.join(directory, name)
                archive.write(path, os.path.relpath(path, ROOT))
print("QC", qc["status"], "ZIP", zip_path,
      f"{os.path.getsize(zip_path)/1e6:.1f} MB")
if qc["status"] != "pass":
    raise RuntimeError("final QC failed")
