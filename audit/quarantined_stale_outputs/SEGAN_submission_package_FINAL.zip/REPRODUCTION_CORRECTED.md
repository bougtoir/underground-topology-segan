# Corrected SEGAN reproduction

Use Python 3.12 and install `requirements.lock.txt` in an isolated environment.
Raw public inputs are preserved under `data/raw/`; canonical originals are
preserved under `audit/originals/`.

Run:

```bash
make final
```

The final target regenerates audits, reconstruction, corrected engineering
results, benchmark comparisons, uncertainty, frozen manuscript values,
figures, DOCX files, QC records and the final ZIP. Runtime is dominated by
24 reconstruction candidates per cluster and the engineering optimizer.
