# 下松市 planning-screening summary

This is a modeled research scenario, not an engineering design or a
reconstruction of the municipality's observed utility network.

- Modeled demand: 17.24 MW
- Like-for-like S1 NPC: 14.09 billion JPY
- Optimized S2 NPC: 13.23 billion JPY
- Modeled S1-S2 difference: 0.87 billion JPY
  (6.14% of S1)
- Maximum modeled MV drop: 0.58%
- Minimum equivalent customer voltage: 0.9679 pu
- Uncertainty P(S1-S2 difference > 0): 1.000

The corrected analysis finds that conductor sizing contributes more modeled
savings than route topology. Project decisions require utility topology,
measured load, field survey, easement, reliability, protection and local bid
data that are unavailable in this study.
