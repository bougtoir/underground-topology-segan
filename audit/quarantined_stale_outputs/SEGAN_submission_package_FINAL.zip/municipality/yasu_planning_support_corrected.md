# 野洲市 planning-screening summary

This is a modeled research scenario, not an engineering design or a
reconstruction of the municipality's observed utility network.

- Modeled demand: 20.01 MW
- Like-for-like S1 NPC: 10.62 billion JPY
- Optimized S2 NPC: 10.08 billion JPY
- Modeled S1-S2 difference: 0.53 billion JPY
  (5.02% of S1)
- Maximum modeled MV drop: 0.42%
- Minimum equivalent customer voltage: 0.9710 pu
- Uncertainty P(S1-S2 difference > 0): 1.000

The corrected analysis finds that conductor sizing contributes more modeled
savings than route topology. Project decisions require utility topology,
measured load, field survey, easement, reliability, protection and local bid
data that are unavailable in this study.
