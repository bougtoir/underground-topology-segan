# 佐野市 planning-screening summary

This is a modeled research scenario, not an engineering design or a
reconstruction of the municipality's observed utility network.

- Modeled demand: 51.48 MW
- Like-for-like S1 NPC: 24.33 billion JPY
- Optimized S2 NPC: 23.32 billion JPY
- Modeled S1-S2 difference: 1.01 billion JPY
  (4.15% of S1)
- Maximum modeled MV drop: 0.32%
- Minimum equivalent customer voltage: 0.9717 pu
- Uncertainty P(S1-S2 difference > 0): 1.000

The corrected analysis finds that conductor sizing contributes more modeled
savings than route topology. Project decisions require utility topology,
measured load, field survey, easement, reliability, protection and local bid
data that are unavailable in this study.
