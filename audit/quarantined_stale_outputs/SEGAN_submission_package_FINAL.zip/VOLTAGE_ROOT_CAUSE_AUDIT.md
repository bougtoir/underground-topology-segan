# Voltage root-cause audit

## Finding

The quarantined 29.16–37.78% voltage-drop results were caused by **both an
implementation defect and a structural network-model defect**. They were not a
valid engineering comparison between feasible alternatives.

## Legacy implementation defects

The legacy evaluator treated every reconstructed road-tree edge as a 415 V
three-phase LV feeder and calculated:

```text
I = P / (sqrt(3) V PF)
delta_V = sqrt(3) I R
```

This had the following consequences.

1. Reactive power and cable reactance were omitted from voltage drop.
2. The 415 V base was inconsistent with the Japanese 100/200 V customer
   service convention and with a 6.6 kV primary distribution route.
3. No source/transformer voltage transformation was represented.
4. No transformer loading, transformer loss or transformer impedance was
   represented.
5. No cable ampacity, voltage, radiality, connectivity or power-balance gate
   could reject an infeasible candidate.
6. Loss energy used load factor directly rather than a declared loss factor.
7. Node identifiers were inconsistently converted between integer-like and
   floating-point strings.

## Structural defects

The implementation defects were compounded by a structural error: each
approximately 350 kW demand cluster was effectively supplied as one aggregated
LV service area. Some individual modeled nodes exceeded 1 MW. The model had no
explicit transformer placement or capacity, no MV primary layer, no LV service
radius, and no mechanism for parallel transformer units. Comparing two
alternatives under the same infeasible representation did not establish
engineering feasibility.

Global Euclidean clustering also mixed demand nodes from disconnected road
components. The reconstruction script then retained only a connected subset,
silently excluding demand from some scenario totals.

## Corrective model

The corrected model freezes and enforces the following hierarchy.

- Road-network distribution edges are balanced three-phase 6.6 kV MV primary
  feeders.
- Every road-snapped demand node is an explicit transformer site.
- Demand at a site is split across parallel catalogued transformer units with
  at most 60 kW per unit and at most 80% design loading.
- Every unit includes a 25 m equivalent 210 V three-phase LV service stub.
  This is a declared assumption because customer-side LV geometry is not
  observed; it is common to S1 and S2 rather than used to manufacture a
  topology advantage.
- Cable resistance, derived reactance, derated ampacity, active and reactive
  power, transformer drop, transformer loss and source voltage are explicit.
- Connectedness, radiality, complete demand service, power balance, ampacity,
  MV drop, transformer drop, LV drop and customer voltage are hard gates.
- Violations are repaired only through transformer splitting or conductor
  sizing. Voltages are not clipped; limits are not relaxed; infeasible
  candidates cannot enter the headline estimate.
- Clustering is performed separately inside each connected road component.
  Singleton clusters are retained.

Cable and transformer parameters are parsed from the archived Fujikura and
Toshiba catalogues. The complete frozen specification is
`ENGINEERING_FEASIBILITY_SPEC.yaml`.

## Quantitative resolution

| Municipality | Legacy maximum drop | Corrected maximum MV drop | Corrected minimum customer voltage |
| --- | ---: | ---: | ---: |
| Sano | 29.16% | 0.321% | 0.9698 pu |
| Kudamatsu | 31.12% | 0.581% | 0.9679 pu |
| Yasu | 37.78% | 0.423% | 0.9710 pu |

All headline S1 and S2 networks are feasible under the frozen gates. Total
modeled demand remains 51.477 MW, 17.241 MW and 20.013 MW, respectively.

The correction materially changes the scientific interpretation:

- S1–S2 NPC savings remain positive, but corrected percentages are 4.17%,
  6.14% and 5.02%, rather than 12.20%, 2.54% and 11.72%.
- Shapley decomposition shows that most corrected savings arise from
  conductor sizing, not route topology: approximately JPY 959 million of JPY
  1,011 million in Sano, JPY 798 million of JPY 866 million in Kudamatsu, and
  JPY 463 million of JPY 533 million in Yasu.
- Corrected best-NPC designs have higher, not lower, peak loss than S1 because
  the economic optimum selects smaller conductors that remain within voltage
  and ampacity gates. The original 60–65% peak-loss-reduction claim therefore
  does not survive.
- The edge-set distance is small and is not a likelihood. It is renamed
  `edge_set_divergence`.

## Benchmark disposition

The corrected radial P/Q line model was compared feeder-by-feeder with AC power
flow on the CIGRE LV benchmark. Minimum-voltage error is 0.00134–0.00256 pu and
line-loss error is 6.49–7.41%; all feeders pass the predeclared 0.003 pu and
10% tolerances. Newton-Raphson, backward/forward sweep and Iwamoto
Newton-Raphson agree quantitatively on the AC reference.

`case11_iwamoto` does not converge under any of those algorithms in the pinned
environment. It is a generic 1 kV stress case, not a documented 6.6 kV Japanese
distribution-design benchmark for this study, and is removed from the main
validation claim.

## Remaining limitations

The correction establishes internal engineering feasibility for the modeled
hierarchy; it does not turn reconstructed networks into observed utility
networks. Transformer locations, 25 m LV service stubs, coincidence, load
factor and costs remain modeled assumptions requiring sensitivity analysis.
S2 remains the best feasible design found in a declared heuristic candidate
family, without a certified global optimality gap.
